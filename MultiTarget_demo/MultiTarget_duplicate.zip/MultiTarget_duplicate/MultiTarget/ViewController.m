//
//  ViewController.m
//  MultiTarget
//
//  Created by 曹雪松 on 2018/7/3.
//  Copyright © 2018 曹雪松. All rights reserved.
//

#import "ViewController.h"
#import <SVProgressHUD/SVProgressHUD.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
#ifdef TARGET_SECOND
    self.view.backgroundColor = [UIColor cyanColor];
    [SVProgressHUD showWithStatus:@"我是Target Second"];
#else
    self.view.backgroundColor = [UIColor orangeColor];
    [SVProgressHUD showWithStatus:@"我是Original Target"];
#endif
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
