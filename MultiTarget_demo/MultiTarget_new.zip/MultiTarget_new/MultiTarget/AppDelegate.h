//
//  AppDelegate.h
//  MultiTarget
//
//  Created by 曹雪松 on 2017/1/25.
//  Copyright © 2017 曹雪松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

