//
//  AppDelegate.h
//  MultiTarget_Second
//
//  Created by 曹雪松 on 2017/1/25.
//  Copyright © 2017 曹雪松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface AppDelegate_Second : AppDelegate <UIApplicationDelegate>


@end

